<?php
include 'Book.php';
include 'Reader.php';
include 'Library.php';

// Пример использования классов
$library = new Library();

$book1 = new Book("1984", "Джордж Оруэлл", 1949);
$book2 = new Book("Война и мир", "Лев Толстой", 1869);
$library->addBook($book1);
$library->addBook($book2);

$reader1 = new Reader("Иван Иванов", "ivan@example.com");
$library->addReader($reader1);

// Читатель берет книгу
$reader1->borrowBook($book1);

// Список книг в библиотеке
$library->listBooks();

// Читатель возвращает книгу
$reader1->returnBook($book1);
?>
